# Cómo poner Mi Biblioteca en tu móvil

La app es una página web que se instala en el móvil como una app normal. Hay que subirla una vez a un sitio gratuito. Unos 10 minutos.

## 1. Subirla a GitHub Pages (gratis)

1. Crea una cuenta en https://github.com (si no tienes).
2. Pulsa **New repository** (botón verde o el «+» de arriba).
   - Nombre: `biblioteca`
   - Márcalo como **Public**
   - Pulsa **Create repository**.
3. En la página del repositorio, pulsa **uploading an existing file**.
4. Arrastra **todos los archivos** de la carpeta (index.html, sw.js, manifest.webmanifest y los tres icon-*.png) y pulsa **Commit changes**.
5. Ve a **Settings → Pages**. En «Branch» elige **main** y **/ (root)** y pulsa **Save**.
6. Espera uno o dos minutos. Tu app estará en:
   `https://TU-USUARIO.github.io/biblioteca/`

Es más cómodo hacerlo desde el ordenador.

## 2. Instalarla en el móvil

Abre ese enlace en el móvil y:

- **Android (Chrome):** menú ⋮ → **Añadir a pantalla de inicio** (o **Instalar app**).
- **iPhone (Safari):** botón Compartir → **Añadir a pantalla de inicio**.

Te queda un icono de estantería, y la app se abre a pantalla completa.

## 3. Uso

- **Añadir libro:** busca por título, autor o ISBN, o pulsa **Escanear código de barras** y apunta a la contraportada. La portada y la sinopsis salen de Google Books (y de Open Library si Google no tiene portada).
- Elige el estado **Pendiente / Leyendo / Leído**. Si está leído, puedes poner la fecha en que lo terminaste, el formato y una puntuación de 1 a 5 estrellas.
- Si un libro no aparece, pulsa **Añadir a mano**. Con **Usar mi foto** le haces una foto a la portada.
- Toca cualquier libro de la estantería para ver la sinopsis completa, editarlo o eliminarlo.

## 4. Copia de seguridad (importante)

Los libros se guardan **en el propio móvil**. El botón de la flecha (arriba a la derecha) → **Guardar copia** crea un archivo que puedes mandarte a Drive, iCloud o por correo. Con **Restaurar copia** lo recuperas en otro móvil o después de borrar los datos del navegador. Haz una copia de vez en cuando.

También puedes fijar ahí tu **objetivo de libros del año**.
